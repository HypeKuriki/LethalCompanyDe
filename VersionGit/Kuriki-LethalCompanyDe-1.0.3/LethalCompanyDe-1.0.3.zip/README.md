## What It Does:
- Just A Little Translation Of Lethal Company For Germans.

## How To Install:

- Use Any Compatible Mod Manager For The Easiest Installation.

OR

- Make Sure You Have [BepInEx](https://thunderstore.io/c/lethal-company/p/BepInEx/BepInExPack/) installed.
- Download This Mod And Put It In Your Game Folder. (`\GAME_LOCATION\Lethal Company\`)

## Credits

- Base Code From - [czech_lethal](https://thunderstore.io/c/lethal-company/p/czech_lethal/czech_translation/), aka. Nufro And Sbni

## Planed

Terminal translation

# Versions

- 1.0.3 Code Rework And Cleanup & Updated Translation For v45

- 1.0.2 Updated Read Me & Bug Fix For Manual Download

- 1.0.1 Mod Manager Support

- 1.0.0 Base Version