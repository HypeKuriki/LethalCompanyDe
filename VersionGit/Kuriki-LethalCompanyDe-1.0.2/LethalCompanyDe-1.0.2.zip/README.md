## What It Does:
- Just a little translation of Lethal Company for Germans.

## How to Install:

- Use any compatible mod manager for the easiest installation.

OR

- Make sure you have [BepInEx](https://thunderstore.io/c/lethal-company/p/BepInEx/BepInExPack/) installed.
- Download this mod and put it in your game folder. (`\GAME_LOCATION\Lethal Company\`)

## Credits

Base code from - [czech_lethal](https://thunderstore.io/c/lethal-company/p/czech_lethal/czech_translation/), aka Nufro and Sbni

## Planed

Terminal translation

# Versions

1.0.2 Updated Read Me & Bug fix for Manual Download

1.0.1 Mod Manager Support

1.0.0 Base Version