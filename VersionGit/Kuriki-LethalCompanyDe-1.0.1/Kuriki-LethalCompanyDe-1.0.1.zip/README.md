## What It Does:
- Just a little translation of Lethal Company for Germans.

## How to Install:

- Use any compatible mod manager for the easiest installation.

OR

- Make sure you have [BepInEx](https://thunderstore.io/c/lethal-company/p/BepInEx/BepInExPack/) installed.
- Download this mod and put it in your game folder. (`\GAME_LOCATION\Lethal Company\`)

